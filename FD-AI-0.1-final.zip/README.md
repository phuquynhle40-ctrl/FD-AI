# FD AI 0.1

FD AI 0.1 là bộ khung AI dạng mô-đun, API-first, được thiết kế theo lộ trình 1→9 trong tài liệu dự án:

1. GitHub — kho mã `FD-AI`
2. Bộ khung — `core / tools / memory`
3. Core — nhận và hiểu lệnh
4. Tool Manager — tự chọn và gọi tool
5. Cài đặt — môi trường / thư viện / API
6. Chạy thử — test tự động + smoke test
7. Video — pipeline/kịch bản → cảnh → giọng → MP4 (0.1 dùng pipeline spec, chưa render MP4 thật)
8. Kiểm tra — tính / viết / dịch / hình / video
9. Nâng cấp — kiến trúc tương thích 0.1 → 0.2 → 1.0 → 5.0

## Mục tiêu kiến trúc

- **API-first:** Android/iOS có thể gọi cùng một backend qua REST/JSON.
- **Modular:** Core không phụ thuộc trực tiếp vào từng tool.
- **Versioned:** API nằm dưới `/api/v1`, thuận tiện thêm `/api/v2` sau này.
- **Persistent memory:** bộ nhớ JSON đơn giản ở 0.1; có thể thay bằng SQLite/PostgreSQL/Vector DB ở các bản sau.
- **Tool registry:** tool mới có thể đăng ký mà không phải viết lại Core.
- **Deterministic 0.1:** các chức năng mẫu chạy offline, không cần API key.

## Chạy nhanh

Yêu cầu Python 3.10+.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows
# .venv\\Scripts\\activate

pip install -r requirements.txt
pip install -e .
python -m fd_ai
```

Sau đó Web + API chạy tại `http://127.0.0.1:8080/`.

## Chạy Web

Mở trình duyệt tới `http://127.0.0.1:8080/`. Web gọi API `/api/v1` và hiển thị trạng thái kết nối.

## Deploy Web công khai

Dự án có sẵn `Dockerfile` và `render.yaml`. Có thể kết nối repository GitHub với một dịch vụ hosting Docker (ví dụ Render) để chạy backend + Web và nhận một địa chỉ HTTPS công khai. Địa chỉ công khai chỉ được tạo sau khi bạn triển khai lên tài khoản hosting; mã nguồn trong ZIP không tự tạo một URL Internet công khai.


## CLI

```bash
python -m fd_ai.cli "tính 12 * 7"
python -m fd_ai.cli "viết một lời chào ngắn"
python -m fd_ai.cli "dịch hello sang vi"
python -m fd_ai.cli "hình logo FD AI màu xanh"
python -m fd_ai.cli "video giới thiệu FD AI 30 giây"
```

## API

- `GET /health`
- `GET /api/v1/info`
- `POST /api/v1/command` với JSON `{"command":"tính 2+2"}`
- `GET /api/v1/memory`
- `POST /api/v1/memory` với JSON `{"key":"...","value":"..."}`

OpenAPI/SDK cho Android và iOS có thể được bổ sung ở các phiên bản sau; xem `mobile/README.md`.

## Tests

```bash
pytest -q
```

## Lộ trình nâng cấp

### 0.2
Thêm LLM provider abstraction, SQLite memory, authentication, streaming và job queue.

### 1.0
Thêm multi-user, permissions, tool sandbox, observability, background jobs và media workers.

### 5.0
Tách Core/Tool/Memory thành services khi cần, thêm model routing, multimodal pipeline, workflow engine, plugin SDK và mobile clients.
