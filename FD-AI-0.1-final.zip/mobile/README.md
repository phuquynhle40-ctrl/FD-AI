# Android / iOS foundation

FD AI 0.1 dùng REST/JSON và không khóa client vào Python. Android (Kotlin/Compose), iOS (Swift/SwiftUI), Flutter hoặc React Native đều có thể gọi:

- `GET /health`
- `GET /api/v1/info`
- `POST /api/v1/command` → `{ "command": "..." }`
- `GET /api/v1/memory`
- `POST /api/v1/memory` → `{ "key": "...", "value": ... }`

Khuyến nghị bản 0.2: sinh OpenAPI schema chính thức và SDK client cho Kotlin/Swift; thêm auth trước khi đưa API ra Internet.
