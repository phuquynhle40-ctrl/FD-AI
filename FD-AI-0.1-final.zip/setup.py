from setuptools import setup, find_packages
setup(
    name="fd-ai",
    version="0.1.0",
    description="FD AI 0.1 modular AI foundation",
    package_dir={"": "src"},
    packages=find_packages("src"),
    python_requires=">=3.10",
)
