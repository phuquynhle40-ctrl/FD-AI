import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from pathlib import Path
from ..config import settings
from ..core.engine import FDEngine
from ..memory.store import MemoryStore

engine = FDEngine(MemoryStore(settings.memory_file))
WEB_ROOT = Path(__file__).resolve().parents[3] / "web"

class Handler(BaseHTTPRequestHandler):
    def _send(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers(); self.wfile.write(body)
    def do_OPTIONS(self):
        self.send_response(204); self.send_header("Access-Control-Allow-Origin","*"); self.send_header("Access-Control-Allow-Headers","Content-Type"); self.send_header("Access-Control-Allow-Methods","GET,POST,OPTIONS"); self.end_headers()
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            return self._send_html(WEB_ROOT / "index.html")
        if path == "/health": self._send(200, {"ok":True,"version":settings.version}); return
        if path == "/api/v1/info": self._send(200, engine.info()); return
        if path == "/api/v1/memory": self._send(200, engine.memory.all()); return
        self._send(404, {"ok":False,"error":"Not found"})
    def _send_html(self, path):
        try:
            body = path.read_bytes()
        except FileNotFoundError:
            self._send(404, {"ok":False,"error":"Web UI not found"}); return
        self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

    def do_POST(self):
        path = urlparse(self.path).path
        length = int(self.headers.get("Content-Length", "0"))
        try: data = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError: self._send(400,{"ok":False,"error":"JSON không hợp lệ"}); return
        if path == "/api/v1/command":
            r = engine.handle(data.get("command", "")); self._send(200 if r.ok else 400, {"ok":r.ok,"tool":r.tool,"data":r.data}); return
        if path == "/api/v1/memory":
            if "key" not in data: self._send(400,{"ok":False,"error":"Thiếu key"}); return
            engine.memory.set(data["key"], data.get("value")); self._send(200,{"ok":True,"key":data["key"]}); return
        self._send(404,{"ok":False,"error":"Not found"})
    def log_message(self, *_): pass

def run():
    print(f"FD AI 0.1 API: http://{settings.host}:{settings.port}")
    ThreadingHTTPServer((settings.host, settings.port), Handler).serve_forever()
