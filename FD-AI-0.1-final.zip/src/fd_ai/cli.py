import sys
from .config import settings
from .core.engine import FDEngine
from .memory.store import MemoryStore

def main():
    engine = FDEngine(MemoryStore(settings.memory_file))
    command = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else input("FD AI > ")
    r = engine.handle(command)
    print(r.data)

if __name__ == "__main__": main()
