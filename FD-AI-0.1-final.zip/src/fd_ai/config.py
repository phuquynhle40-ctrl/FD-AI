import os
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class Settings:
    version: str = os.getenv("FD_AI_VERSION", "0.1.0")
    host: str = os.getenv("FD_AI_HOST", "127.0.0.1")
    port: int = int(os.getenv("PORT", os.getenv("FD_AI_PORT", "8080")))
    memory_file: Path = Path(os.getenv("FD_AI_MEMORY_FILE", "data/memory.json"))

settings = Settings()
