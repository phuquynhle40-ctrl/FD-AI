from dataclasses import dataclass
from ..memory.store import MemoryStore
from ..tools.registry import ToolManager
from ..tools.builtins import CalculatorTool, WriterTool, TranslatorTool, ImageTool, VideoTool

@dataclass
class CommandResponse:
    ok: bool
    tool: str
    data: dict

class FDEngine:
    def __init__(self, memory: MemoryStore):
        self.memory = memory
        self.tools = ToolManager()
        for tool in (CalculatorTool(), WriterTool(), TranslatorTool(), ImageTool(), VideoTool()):
            self.tools.register(tool)

    def info(self):
        return {"name":"FD AI", "version":"0.1.0", "api_version":"v1", "tools":self.tools.list_tools()}

    def handle(self, command: str) -> CommandResponse:
        command = (command or "").strip()
        if not command:
            return CommandResponse(False, "none", {"error":"Lệnh trống"})
        result = self.tools.execute(command)
        return CommandResponse(result.ok, result.tool, result.data)
