from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

@dataclass
class ToolResult:
    tool: str
    ok: bool
    data: Any

class Tool(ABC):
    name: str
    description: str

    @abstractmethod
    def can_handle(self, command: str) -> bool: ...

    @abstractmethod
    def run(self, command: str) -> ToolResult: ...
