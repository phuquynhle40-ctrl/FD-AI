import ast
import operator
import re
from .base import Tool, ToolResult

_ALLOWED = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
            ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
            ast.USub: operator.neg}

def safe_eval(expr: str):
    tree = ast.parse(expr, mode="eval")
    def visit(node):
        if isinstance(node, ast.Expression): return visit(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)): return node.value
        if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED: return _ALLOWED[type(node.op)](visit(node.operand))
        if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED: return _ALLOWED[type(node.op)](visit(node.left), visit(node.right))
        raise ValueError("Biểu thức không được phép")
    return visit(tree)

class CalculatorTool(Tool):
    name = "calculator"
    description = "Tính biểu thức số học an toàn"
    def can_handle(self, command): return command.strip().lower().startswith(("tính ", "tinh "))
    def run(self, command):
        expr = re.sub(r"^(tính|tinh)\s+", "", command.strip(), flags=re.I)
        try: return ToolResult(self.name, True, {"expression": expr, "result": safe_eval(expr)})
        except Exception as e: return ToolResult(self.name, False, {"error": str(e)})

class WriterTool(Tool):
    name = "writer"
    description = "Tạo bản nháp văn bản"
    def can_handle(self, command): return command.strip().lower().startswith(("viết ", "viet "))
    def run(self, command):
        prompt = re.sub(r"^(viết|viet)\s+", "", command.strip(), flags=re.I)
        return ToolResult(self.name, True, {"draft": f"FD AI 0.1 — Bản nháp: {prompt}"})

class TranslatorTool(Tool):
    name = "translator"
    description = "Dịch mẫu Anh↔Việt trong bản 0.1"
    dictionary = {"hello":"xin chào", "good morning":"chào buổi sáng", "thank you":"cảm ơn", "xin chào":"hello", "cảm ơn":"thank you"}
    def can_handle(self, command): return bool(re.match(r"^(dịch|dich)\s+.+\s+(sang|to)\s+(vi|en|tiếng việt|tiếng anh)$", command.strip(), re.I))
    def run(self, command):
        m = re.match(r"^(?:dịch|dich)\s+(.+?)\s+(?:sang|to)\s+(vi|en|tiếng việt|tiếng anh)$", command.strip(), re.I)
        text, target = m.group(1).lower(), m.group(2).lower()
        result = self.dictionary.get(text, f"[Bản 0.1] Chưa có mục từ: {text}")
        return ToolResult(self.name, True, {"source": text, "target": target, "translation": result})

class ImageTool(Tool):
    name = "image"
    description = "Tạo image-generation specification cho bản 0.1"
    def can_handle(self, command): return command.strip().lower().startswith(("hình ", "hinh "))
    def run(self, command):
        prompt = re.sub(r"^(hình|hinh)\s+", "", command.strip(), flags=re.I)
        return ToolResult(self.name, True, {"status":"spec-ready", "prompt":prompt, "format":"png", "next":"connect image provider in 0.2+"})

class VideoTool(Tool):
    name = "video"
    description = "Tạo video pipeline specification"
    def can_handle(self, command): return command.strip().lower().startswith(("video ", "vidéo "))
    def run(self, command):
        prompt = re.sub(r"^(video|vidéo)\s+", "", command.strip(), flags=re.I)
        return ToolResult(self.name, True, {"status":"pipeline-ready", "script":prompt, "stages":["script","scenes","voice","render_mp4"], "format":"mp4"})
