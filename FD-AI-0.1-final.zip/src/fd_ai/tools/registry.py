from .base import Tool, ToolResult

class ToolManager:
    def __init__(self):
        self._tools: list[Tool] = []

    def register(self, tool: Tool) -> None:
        self._tools.append(tool)

    def list_tools(self) -> list[str]:
        return [tool.name for tool in self._tools]

    def choose(self, command: str) -> Tool | None:
        for tool in self._tools:
            if tool.can_handle(command):
                return tool
        return None

    def execute(self, command: str) -> ToolResult:
        tool = self.choose(command)
        if tool is None:
            return ToolResult("none", False, {"error": "Không hiểu lệnh trong FD AI 0.1", "command": command})
        return tool.run(command)
