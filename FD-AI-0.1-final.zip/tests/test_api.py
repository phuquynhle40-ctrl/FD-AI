import json, threading
from http.server import ThreadingHTTPServer
import fd_ai.api.server as server

def test_api_health(monkeypatch):
    httpd=ThreadingHTTPServer(("127.0.0.1",0), server.Handler)
    t=threading.Thread(target=httpd.serve_forever, daemon=True); t.start()
    import urllib.request
    with urllib.request.urlopen(f"http://127.0.0.1:{httpd.server_port}/health") as r:
        data=json.loads(r.read())
    httpd.shutdown()
    assert data["ok"] is True


def test_web_root():
    from fd_ai.api.server import Handler
    assert (Handler.__module__.split(".")[0] == "fd_ai")
