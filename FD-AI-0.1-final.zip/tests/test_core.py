from pathlib import Path
from fd_ai.core.engine import FDEngine
from fd_ai.memory.store import MemoryStore

def engine(tmp_path): return FDEngine(MemoryStore(tmp_path / "memory.json"))

def test_calculator(tmp_path):
    r=engine(tmp_path).handle("tính 12 * 7")
    assert r.ok and r.tool == "calculator" and r.data["result"] == 84

def test_writer(tmp_path):
    r=engine(tmp_path).handle("viết một lời chào")
    assert r.ok and r.tool == "writer" and "lời chào" in r.data["draft"]

def test_translator(tmp_path):
    r=engine(tmp_path).handle("dịch hello sang vi")
    assert r.ok and r.data["translation"] == "xin chào"

def test_image(tmp_path):
    r=engine(tmp_path).handle("hình logo FD AI")
    assert r.ok and r.tool == "image" and r.data["format"] == "png"

def test_video(tmp_path):
    r=engine(tmp_path).handle("video giới thiệu FD AI")
    assert r.ok and r.tool == "video" and r.data["format"] == "mp4"

def test_memory(tmp_path):
    e=engine(tmp_path); e.memory.set("project","FD AI")
    assert e.memory.get("project") == "FD AI"
