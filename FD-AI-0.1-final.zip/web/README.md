# FD AI 0.1 Web

Web UI của FD AI 0.1 được phục vụ trực tiếp bởi API server tại `/`.

Chạy:

```bash
pip install -r requirements.txt
pip install -e .
./run_web.sh
```

Mở `http://127.0.0.1:8080/`.

Để triển khai Internet công khai, dùng một host chạy Python server (Render, Railway, Fly.io, VPS...) hoặc đóng gói backend thành container. GitHub Pages chỉ phù hợp cho frontend tĩnh, không chạy API backend Python.
