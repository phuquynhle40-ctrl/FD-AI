class ModuleManager:
    def __init__(self):
        self.modules = {
            "core": {
                "name": "core",
                "description": "Lõi điều phối của FD AI."
            },
            "chat": {
                "name": "chat",
                "description": "Giao diện và xử lý hội thoại cơ bản."
            }
        }

    def list_modules(self):
        return list(self.modules.keys())
