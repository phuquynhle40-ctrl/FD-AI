class ToolManager:
    def __init__(self):
        self.tools = {
            "echo": {
                "name": "echo",
                "description": "Trả lời lại yêu cầu cơ bản của người dùng."
            },
            "status": {
                "name": "status",
                "description": "Kiểm tra trạng thái FD AI."
            }
        }

    def list_tools(self):
        return list(self.tools.keys())
