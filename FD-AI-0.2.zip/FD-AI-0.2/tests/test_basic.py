def test_version_path():
    from src.version_manager.manager import VersionManager
    vm = VersionManager()
    assert vm.current_version() == "0.2.0"
    assert vm.upgrade_path()[-1] == "5.0.0"
