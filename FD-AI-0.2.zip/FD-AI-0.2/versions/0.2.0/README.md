# FD AI 0.2.0

Bản phát hành nền tảng đầu tiên của FD AI 0.2.
